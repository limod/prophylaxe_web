<?php

class Application_Model_DbTable_ContactPoint extends Zend_Db_Table_Abstract
{

    protected $_name = 'spl_contact_point';


}

