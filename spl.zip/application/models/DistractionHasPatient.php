<?php

class Application_Model_DistractionHasPatient
{


}

